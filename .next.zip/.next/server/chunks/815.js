"use strict";
exports.id = 815;
exports.ids = [815];
exports.modules = {

/***/ 4815:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Template)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Logo.tsx




const Logo = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center my-10 mx-20",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/",
                className: "grid content-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: "/images/logo.png",
                        width: 250,
                        height: 50,
                        className: "hover:cursor-pointer"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-lg text-slate-600 ml-10",
                children: "unique projects with source code"
            })
        ]
    });
};
/* harmony default export */ const components_Logo = (Logo);

// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
var external_lodash_default = /*#__PURE__*/__webpack_require__.n(external_lodash_);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
;// CONCATENATED MODULE: ./components/Navbar.tsx





function Navbar() {
    const { 0: categories , 1: setCategories  } = (0,external_react_.useState)([
        "JavaScript",
        "React JS",
        "Node.js",
        "C/C++",
        "ExpressJS",
        "PostgreSQL",
        "SQLite",
        "Laravel",
        "Vue.js",
        "HTML/CSS",
        "dJango",
        "Mongoose",
        "Bulma",
        "MySQL",
        "PHP",
        "SQL",
        "Python",
        "Deno",
        "MongoDB",
        "NextJS"
    ]);
    (0,external_react_.useEffect)(()=>{
        setCategories(external_lodash_default().shuffle(categories));
    }, []);
    const { 0: searchValue , 1: setSearchValue  } = (0,external_react_.useState)("");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-blue-800 px-16 flex justify-between",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "flex text-slate-50",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Suspense, {
                    children: categories?.slice(0, 8).map((category, idx)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "px-4 py-4 hover:bg-blue-900",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: {
                                    pathname: "/",
                                    query: {
                                        category: category
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "text-white",
                                    children: category
                                })
                            })
                        }, idx)
                    )
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex rounded-md shadow-sm justify-center relative items-center",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "xl:w-64",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "my-auto input-group relative flex items-stretch w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "search",
                                className: "form-control relative flex-auto min-w-0 block w-full px-4 py-1.5 text-base font-normal text-gray-700 bg-white bg-clip-padding border-gray-300 rounded-l-full transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none",
                                placeholder: "Search",
                                "aria-label": "Search",
                                "aria-describedby": "button-addon2",
                                onChange: (e)=>{
                                    // console.log(e.target.value);
                                    setSearchValue(e.target.value);
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "inline-block px-4 py-2 bg-blue-600 text-white font-medium text-xs leading-tight uppercase shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out flex items-center",
                                type: "button",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: {
                                        pathname: "/",
                                        query: {
                                            search: searchValue
                                        }
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "text-white text-xl",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiSearchEyeLine, {})
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const components_Navbar = (Navbar);

;// CONCATENATED MODULE: ./components/Footer.tsx



const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "px-16 text-white bg-gray-800 py-4",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "codegenes \xa9 2022"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/privacy-policy",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "text-white",
                                children: "Privacy"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/about",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "text-white ml-4",
                                children: "About"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_Footer = (Footer);

;// CONCATENATED MODULE: ./components/Template.tsx

// fronted wrapper




function Template({ children  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Codegenes"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "unique projects with source code"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Logo, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Navbar, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "mx-20 my-5 h-full",
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Footer, {})
        ]
    });
};


/***/ })

};
;