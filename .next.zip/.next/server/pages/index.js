"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 8504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "fs"
var external_fs_ = __webpack_require__(7147);
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_);
// EXTERNAL MODULE: external "gray-matter"
var external_gray_matter_ = __webpack_require__(8076);
var external_gray_matter_default = /*#__PURE__*/__webpack_require__.n(external_gray_matter_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "path"
var external_path_ = __webpack_require__(1017);
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Post.tsx




const Post = ({ post  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "p-6 m-2 mt-4 rounded-lg shadow-lg hover:shadow-gray-400 relative",
        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
            href: `/blog/${post.slug}`,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hover:cursor-pointer",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full h-56 relative",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: post.frontmatter?.cover_image ? post.frontmatter.cover_image : "/images/placeholder.webp",
                            layout: "fill",
                            objectFit: "cover",
                            alt: post.title,
                            priority: true
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "text-md text-blue-700 my-2",
                        children: post.frontmatter?.categories
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-2xl font-bold hover:text-red-500",
                        children: post.frontmatter.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-slate-500 my-2"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-slate-500",
                            children: post.frontmatter.date
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const components_Post = (Post);

// EXTERNAL MODULE: ./components/Template.tsx + 3 modules
var Template = __webpack_require__(4815);
;// CONCATENATED MODULE: ./utils/index.ts
const sortByDate = (a, b)=>{
    return Number(new Date(b.frontmatter.date)) - Number(new Date(a.frontmatter.date));
};

;// CONCATENATED MODULE: ./pages/index.tsx









function Home({ posts  }) {
    const router = (0,router_.useRouter)();
    const { category , search  } = router.query;
    if (category) {
        posts = posts?.filter((post)=>post?.frontmatter.categories?.includes(category)
        );
    }
    if (search) {
        posts = posts?.filter((post)=>post?.content?.includes(search)
        );
    }
    const { 0: totalPosts , 1: setTotalPosts  } = (0,external_react_.useState)(6);
    const len = posts.length;
    return /*#__PURE__*/ jsx_runtime_.jsx(Template/* default */.Z, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mx-auto text-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "grid md:grid-cols-3 sm:grid-cols-2 gap-4 text-left",
                    children: posts?.slice(0, totalPosts).map((post, idx)=>/*#__PURE__*/ jsx_runtime_.jsx(components_Post, {
                            post: post
                        }, idx)
                    )
                }),
                totalPosts <= len && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "bg-blue-600 rounded-full text-white py-2 px-4 mt-4 shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out",
                    onClick: ()=>setTotalPosts(totalPosts + 6)
                    ,
                    children: "Load More"
                })
            ]
        })
    });
}
const getStaticProps = ()=>{
    // Get files from the posts dir
    const files = external_fs_default().readdirSync(external_path_default().join("posts"));
    // Get slug and frontmatter from posts
    const posts = files.map((filename)=>{
        // Create slug
        const slug = filename.replace(".mdx", "");
        // Get frontmatter
        const markdownWithMeta = external_fs_default().readFileSync(external_path_default().join("posts", filename), "utf-8");
        // console.log(slug);
        try {
            const { data: frontmatter , content  } = external_gray_matter_default()(markdownWithMeta);
            // frontmatter?.categories.split(', ').forEach(cat => { categories.push(cat) });
            return {
                slug,
                frontmatter,
                content
            };
        } catch (error) {
            console.log(error);
        }
    });
    // console.log(Array.from(new Set(categories)));
    return {
        props: {
            posts: posts.sort(sortByDate)
        }
    };
};
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 8076:
/***/ ((module) => {

module.exports = require("gray-matter");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,61,815], () => (__webpack_exec__(8504)));
module.exports = __webpack_exports__;

})();